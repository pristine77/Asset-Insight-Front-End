import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';

type FlashMode = 'off' | 'on' | 'auto';

interface TopControlsProps {
  flash: FlashMode;
  focusOn: boolean;
  onFlashToggle: () => void;
  onFocusToggle: () => void;
  onDone: () => void;
  isLandscape?: boolean;
}

const FLASH_ICONS: Record<FlashMode, string> = {
  on: 'zap',
  auto: 'zap',
  off: 'zap-off',
};

const FLASH_LABELS: Record<FlashMode, string> = {
  on: 'ON',
  auto: 'AUTO',
  off: 'OFF',
};

export const TopControls: React.FC<TopControlsProps> = ({
  flash,
  focusOn,
  onFlashToggle,
  onFocusToggle,
  onDone,
  isLandscape = false,
}) => {
  return (
    <View style={styles.rightControls}>
      <TouchableOpacity onPress={onFlashToggle} style={styles.controlBtn}>
        <Feather
          name={FLASH_ICONS[flash] as any}
          size={22}
          color={flash === 'on' ? '#FCD34D' : '#fff'}
        />
        <Text style={styles.controlLabel}>{FLASH_LABELS[flash]}</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={onFocusToggle}
        style={[styles.controlBtn, focusOn && styles.controlBtnActive]}>
        <Feather name="crosshair" size={22} color={focusOn ? '#fff' : '#fff'} />
        <Text style={[styles.controlLabel, focusOn && styles.controlLabelActive]}>Focus</Text>
      </TouchableOpacity>
    </View>
  );
};

interface DoneButtonProps {
  onDone: () => void;
}

export const DoneButton: React.FC<DoneButtonProps> = ({ onDone }) => {
  return (
    <TouchableOpacity onPress={onDone} style={styles.doneBtn}>
      <Feather name="check" size={24} color="#10B981" />
      <Text style={styles.doneBtnLabel}>Done</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  rightControls: {
    flexDirection: 'row',
    gap: 8,
  },
  controlBtn: {
    padding: 10,
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: 12,
    minWidth: 54,
  },
  controlBtnActive: {
    backgroundColor: 'rgba(239, 68, 68, 0.7)',
  },
  controlLabel: {
    color: '#fff',
    fontSize: 10,
    marginTop: 2,
  },
  controlLabelActive: {
    fontWeight: 'bold',
  },
  doneBtn: {
    padding: 10,
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderRadius: 12,
    minWidth: 54,
  },
  doneBtnLabel: {
    color: '#10B981',
    fontSize: 10,
    marginTop: 2,
    fontWeight: 'bold',
  },
});

export default TopControls;
