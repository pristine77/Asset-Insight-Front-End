import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  PanResponder,
  TouchableOpacity,
  Text,
} from 'react-native';
import { Feather } from '@expo/vector-icons';

interface FocusBoxProps {
  visible: boolean;
  isLandscape?: boolean;
}

const MIN_SIZE = 80;
const MAX_SIZE_RATIO = 0.9;

export const FocusBox: React.FC<FocusBoxProps> = ({ visible, isLandscape = false }) => {
  const { width: screenWidth, height: screenHeight } = Dimensions.get('window');
  
  // Default size based on orientation
  const defaultWidth = isLandscape ? screenWidth * 0.5 : screenWidth * 0.65;
  const defaultHeight = isLandscape ? screenHeight * 0.7 : screenHeight * 0.35;
  
  // State for position, size, and minimized state
  const [position, setPosition] = useState({ x: 0, y: 0 }); // Offset from center
  const [size, setSize] = useState({ width: defaultWidth, height: defaultHeight });
  const [isMinimized, setIsMinimized] = useState(false);
  
  // Refs for gesture handling
  const lastPosition = useRef({ x: 0, y: 0 });
  const lastSize = useRef({ width: defaultWidth, height: defaultHeight });
  
  // Pan responder for moving the box
  const movePanResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        lastPosition.current = { ...position };
      },
      onPanResponderMove: (_, gestureState) => {
        const newX = lastPosition.current.x + gestureState.dx;
        const newY = lastPosition.current.y + gestureState.dy;
        
        // Clamp to screen bounds
        const maxX = (screenWidth - size.width) / 2;
        const maxY = (screenHeight - size.height) / 2;
        
        setPosition({
          x: Math.max(-maxX, Math.min(maxX, newX)),
          y: Math.max(-maxY, Math.min(maxY, newY)),
        });
      },
      onPanResponderRelease: () => {
        lastPosition.current = { ...position };
      },
    })
  ).current;
  
  // Pan responder for resizing (corner drag)
  const createResizePanResponder = useCallback((corner: 'tl' | 'tr' | 'bl' | 'br') => {
    return PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        lastSize.current = { ...size };
        lastPosition.current = { ...position };
      },
      onPanResponderMove: (_, gestureState) => {
        let dw = 0;
        let dh = 0;
        let dx = 0;
        let dy = 0;
        
        // Calculate size change based on corner
        if (corner === 'br') {
          dw = gestureState.dx * 2;
          dh = gestureState.dy * 2;
        } else if (corner === 'bl') {
          dw = -gestureState.dx * 2;
          dh = gestureState.dy * 2;
        } else if (corner === 'tr') {
          dw = gestureState.dx * 2;
          dh = -gestureState.dy * 2;
        } else if (corner === 'tl') {
          dw = -gestureState.dx * 2;
          dh = -gestureState.dy * 2;
        }
        
        const newWidth = Math.max(MIN_SIZE, Math.min(screenWidth * MAX_SIZE_RATIO, lastSize.current.width + dw));
        const newHeight = Math.max(MIN_SIZE, Math.min(screenHeight * MAX_SIZE_RATIO, lastSize.current.height + dh));
        
        setSize({ width: newWidth, height: newHeight });
      },
      onPanResponderRelease: () => {
        lastSize.current = { ...size };
      },
    });
  }, [size, position, screenWidth, screenHeight]);
  
  const resizeTL = useRef(createResizePanResponder('tl')).current;
  const resizeTR = useRef(createResizePanResponder('tr')).current;
  const resizeBL = useRef(createResizePanResponder('bl')).current;
  const resizeBR = useRef(createResizePanResponder('br')).current;
  
  const toggleMinimize = useCallback(() => {
    setIsMinimized((prev) => !prev);
  }, []);
  
  const resetBox = useCallback(() => {
    setPosition({ x: 0, y: 0 });
    setSize({ width: defaultWidth, height: defaultHeight });
    setIsMinimized(false);
  }, [defaultWidth, defaultHeight]);

  if (!visible) return null;

  // Minimized state - just show a small button to restore
  if (isMinimized) {
    return (
      <View style={styles.minimizedContainer} pointerEvents="box-none">
        <TouchableOpacity style={styles.minimizedButton} onPress={toggleMinimize}>
          <Feather name="maximize-2" size={16} color="#EF4444" />
          <Text style={styles.minimizedText}>AI Focus</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container} pointerEvents="box-none">
      <View
        style={[
          styles.focusBox,
          {
            width: size.width,
            height: size.height,
            transform: [{ translateX: position.x }, { translateY: position.y }],
          },
        ]}>
        {/* Move handle - center top */}
        <View style={styles.moveHandle} {...movePanResponder.panHandlers}>
          <Feather name="move" size={14} color="#fff" />
        </View>
        
        {/* Control buttons - top right */}
        <View style={styles.controlButtons}>
          <TouchableOpacity style={styles.controlBtn} onPress={toggleMinimize}>
            <Feather name="minimize-2" size={12} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.controlBtn} onPress={resetBox}>
            <Feather name="refresh-cw" size={12} color="#fff" />
          </TouchableOpacity>
        </View>
        
        {/* Resize corners */}
        <View style={[styles.corner, styles.cornerTL]} {...resizeTL.panHandlers}>
          <View style={styles.cornerInner} />
        </View>
        <View style={[styles.corner, styles.cornerTR]} {...resizeTR.panHandlers}>
          <View style={styles.cornerInner} />
        </View>
        <View style={[styles.corner, styles.cornerBL]} {...resizeBL.panHandlers}>
          <View style={styles.cornerInner} />
        </View>
        <View style={[styles.corner, styles.cornerBR]} {...resizeBR.panHandlers}>
          <View style={styles.cornerInner} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  minimizedContainer: {
    position: 'absolute',
    top: 100,
    right: 10,
  },
  minimizedButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: '#EF4444',
    gap: 4,
  },
  minimizedText: {
    color: '#EF4444',
    fontSize: 11,
    fontWeight: '600',
  },
  focusBox: {
    borderWidth: 2.5,
    borderColor: '#EF4444',
    borderRadius: 4,
    backgroundColor: 'transparent',
  },
  moveHandle: {
    position: 'absolute',
    top: -28,
    left: '50%',
    marginLeft: -20,
    width: 40,
    height: 24,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  controlButtons: {
    position: 'absolute',
    top: -28,
    right: 0,
    flexDirection: 'row',
    gap: 4,
  },
  controlBtn: {
    width: 24,
    height: 24,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  corner: {
    position: 'absolute',
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cornerInner: {
    width: 16,
    height: 16,
    borderColor: '#EF4444',
    borderWidth: 3,
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderRadius: 3,
  },
  cornerTL: {
    top: -16,
    left: -16,
  },
  cornerTR: {
    top: -16,
    right: -16,
  },
  cornerBL: {
    bottom: -16,
    left: -16,
  },
  cornerBR: {
    bottom: -16,
    right: -16,
  },
});

export default FocusBox;
